const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Room = require('../models/Room');

// POST a new booking
router.post('/', async (req, res) => {
    const { guestName, guestEmail, roomId, checkInDate, checkOutDate } = req.body;

    try {
        // 1. Check room availability (simplified)
        const room = await Room.findById(roomId);
        if (!room || !room.isAvailable) {
            return res.status(400).json({ message: 'Room is not available' });
        }

        // 2. Calculate total price (simple day rate calculation)
        const checkIn = new Date(checkInDate);
        const checkOut = new Date(checkOutDate);
        const nights = (checkOut - checkIn) / (1000 * 60 * 60 * 24);
        const totalPrice = nights * room.price;

        // 3. Create booking
        const booking = new Booking({
            guestName,
            guestEmail,
            room: roomId,
            checkInDate: checkIn,
            checkOutDate: checkOut,
            totalPrice,
        });

        const newBooking = await booking.save();

        // 4. Update room status to unavailable
        room.isAvailable = false;
        await room.save();

        res.status(201).json(newBooking);

    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// GET all bookings (Admin function)
router.get('/', async (req, res) => {
    try {
        const bookings = await Booking.find().populate('room'); // Populate room details
        res.json(bookings);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;