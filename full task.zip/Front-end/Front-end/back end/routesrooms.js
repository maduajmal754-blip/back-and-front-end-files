const express = require('express');
const router = express.Router();
const Room = require('../models/Room');

// GET all available rooms
router.get('/', async (req, res) => {
    try {
        const rooms = await Room.find({ isAvailable: true });
        res.json(rooms);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST a new room (Admin function)
router.post('/', async (req, res) => {
    const room = new Room({
        roomNumber: req.body.roomNumber,
        roomType: req.body.roomType,
        price: req.body.price,
    });
    try {
        const newRoom = await room.save();
        res.status(201).json(newRoom);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

module.exports = router;