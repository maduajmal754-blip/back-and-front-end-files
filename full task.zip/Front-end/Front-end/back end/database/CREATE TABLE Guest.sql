CREATE TABLE Guest (
	GuestID INT PRIMARY KEY,
	FirstName VARCHAR(50),
	LastName VARCHAR(50),
	DateOfBirth DATE,
	Address VARCHAR(255),
	Phone VARCHAR(15),
	Email VARCHAR(255)
);