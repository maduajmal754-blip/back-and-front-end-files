CREATE TABLE Booking (
	BookingID INT PRIMARY KEY,
	GuestID INT,
	RoomNumber INT,
	CheckinDate DATE,
	CheckoutDate DATE,
	TotalPrice DECIMAL(10, 2),
	FOREIGN KEY (GuestID) REFERENCES Guest(GuestID),
	FOREIGN KEY (RoomNumber) REFERENCES Room(RoomNumber)
);
