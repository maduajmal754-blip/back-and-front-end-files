CREATE TABLE Hotel (
	HotelID INT PRIMARY KEY,
	Name VARCHAR(255),
	Address VARCHAR(255),
	Phone VARCHAR(15),
	Email VARCHAR(255),
	Stars INT,
	CheckinTime TIME,
	CheckoutTime TIME
);