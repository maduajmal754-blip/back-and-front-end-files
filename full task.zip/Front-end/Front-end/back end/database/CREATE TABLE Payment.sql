CREATE TABLE Payment (
	PaymentID INT PRIMARY KEY,
	BookingID INT,
	Amount DECIMAL(10, 2),
	PaymentDate DATE,
	PaymentMethod VARCHAR(50),
	FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);