CREATE TABLE RoomType (
	TypeID INT PRIMARY KEY,
	Name VARCHAR(50),
	Description VARCHAR(255),
	PricePerNight DECIMAL(10, 2),
	Capacity INT
);